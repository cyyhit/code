% =========================================================================
% This is a sample code for testing our NonLRMA algorithm
% for HSI denoising, Version 1.0
% Copyright(c) 2017 Yongyong Chen, Yanwen Guo
% All Rights Reserved.
%
% ----------------------------------------------------------------------
% Permission to use, copy, or modify this software and its documentation
% for educational and research purposes only and without fee is here
% granted, provided that this copyright notice and the original authors'
% names appear on all copies and supporting documentation. This program
% shall not be used, rewritten, or adapted as the basis of a commercial
% software or hardware product without first obtaining permission of the
% authors. The authors make no representations about the suitability of
% this software for any purpose. It is provided "as is" without express
% or implied warranty.
%----------------------------------------------------------------------
%
% This is an implementation of the algorithm for HSI denoising
% 
% Please cite the following paper if you use this code:
% Yongyong Chen,  Yanwen Guo, Yongli Wang et.al
%"Denoising of Hyperspectral Images Using Nonconvex Low Rank Matrix Approximation[J]
% March, 23, 2017. Yongyong Chen. Email: skdcy2012@163.com
%-------------------------------------------------------------------


clear all;
close all;
clc;	

%% Load HSI data
Noise_Urban = double(imread('urban.tif'));
[m,n,p]  = size(Noise_Urban);
MINDN = min(Noise_Urban(:));
MAXDN = max(Noise_Urban(:));
Interval = MAXDN - MINDN;
Noise_Urban = (Noise_Urban - MINDN)/Interval;

%% Call the main function
blocksize = 50;  
stepsize  = 16;
name = 'Urban';
strname = 'Lap';
[ output_image ] = NonLRMA_HSIdenoise( Noise_Urban,blocksize,stepsize,name,strname);
%% Show results
figure
set(gcf,'Position',[10,30,1600,480]); 
for i = 1:p
    subplot(1,2,1)
    imshow(Noise_Urban(:,:,i),[]);
    title('Noisy HSI')
    subplot(1,2,2)
    imshow(output_image(:,:,i),[]);
    title('Recovered HSI');
    pause(0.1);
end
%%
