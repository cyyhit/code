function r = exe(q)
% Extracts the X component of a quaternion.

% Copyright � 2005 Stephen J. Sangwine and Nicolas Le Bihan.
% See the file : Copyright.m for further details.

% error(nargchk(1, 1, nargin)), error(nargoutchk(0, 1, nargout))

error('Obsolete private function exe called.')

r = q.x;

% $Id: exe.m,v 1.3 2010/05/13 20:33:55 sangwine Exp $
